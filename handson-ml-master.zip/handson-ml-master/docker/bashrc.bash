alias ll="ls -alF"
alias nbd="nbdiff_checkpoint"
alias tb="tensorboard --logdir=tf_logs"
